from datetime import datetime
from typing import List, Optional
from sqlmodel import Session, select
from .model import Categoria

class CategoriaRepository:
    def __init__(self, session: Session):
        self.session = session

    def get_all(self, activo: Optional[bool] = None) -> List[Categoria]:
        consulta = select(Categoria)
        if activo is not None:
            consulta = select(Categoria).where(Categoria.activo == activo)
        return self.session.exec(consulta).all()

    def get_all_short(self) -> List[Categoria]:
        consulta = select(Categoria)
        return self.session.exec(consulta).all()

    def get_by_id(self, id: int) -> Optional[Categoria]:
        return self.session.get(Categoria, id)

    def create(self, categoria: Categoria) -> Categoria:
        self.session.add(categoria)
        return categoria

    def update(self, id: int, update: Categoria) -> Optional[Categoria]:
        categoria = self.session.get(Categoria, id)
        if not categoria:
            return None

        for key, value in update.model_dump(exclude_unset=True).items():
            setattr(categoria, key, value)

        categoria.updated_at = datetime.now()

        self.session.add(categoria)

        return categoria

    def delete(self, id: int) -> Optional[Categoria]:
        categoria = self.session.get(Categoria, id)
        if not categoria:
            return None

        categoria.activo = False
        categoria.deleted_at = datetime.now()

        self.session.add(categoria)

        return categoria
