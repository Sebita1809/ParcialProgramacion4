from datetime import datetime
from typing import List, Optional
from app.core.unit_of_work import UnitOfWork
from .model import Categoria
from .schema import CategoriaCreate, CategoriaRead, CategoriaReadShort, CategoriaUpdate


class CategoriaService:

    def __init__(self, uow: UnitOfWork) -> None:
        self.uow = uow

    def obtener_todos(self, activo: Optional[bool] = None) -> List[CategoriaRead]:
        with self.uow:
            return self.uow.categorias.get_all(activo=activo)
    
    def obtener_todos_short(self) -> List[CategoriaReadShort]:
        with self.uow:
            return self.uow.categorias.get_all_short()
    
    def obtener_por_id(self, id: int) -> CategoriaRead:
        with self.uow:
            return self.uow.categorias.get_by_id(id)

    def crear_categoria(self, categoria: CategoriaCreate) -> CategoriaRead:
        with self.uow:
            datos_categoria = categoria.model_dump()
            nueva_categoria = Categoria(**datos_categoria, created_at=datetime.now(), updated_at=datetime.now())
            self.uow.categorias.create(nueva_categoria)

            self.uow.session.flush()
            self.uow.session.refresh(nueva_categoria)

        return nueva_categoria

    def editar_categoria(self, id: int ,update: CategoriaUpdate) -> CategoriaRead:
        with self.uow:
            nueva_categoria = self.uow.categorias.update(id, update)
            if not nueva_categoria:
                return None

            self.uow.session.flush()
            self.uow.session.refresh(nueva_categoria)

            return nueva_categoria

    def eliminar_categoria_logico(self, id: int) -> CategoriaRead:
        with self.uow:
            categoria = self.uow.categorias.get_by_id(id)
            if not categoria:
                return None
            
            self.uow.categorias.delete(id)

            self.uow.session.flush()
            self.uow.session.refresh(categoria)

            return categoria

            