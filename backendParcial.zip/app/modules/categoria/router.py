from fastapi import APIRouter, HTTPException, Depends, Path, Query
from typing import Annotated, List, Optional
from app.core.unit_of_work import UnitOfWork
from app.modules.categoria.schema import CategoriaCreate, CategoriaRead, CategoriaUpdate
from app.modules.categoria.service import CategoriaService
UOW_Dep = Annotated[UnitOfWork, Depends(UnitOfWork)]

categoria_router = APIRouter(prefix="/categories", tags=["Categorias"])

@categoria_router.get("/", response_model=List[CategoriaRead])
def listar_categorias(
    uow: UOW_Dep,
    activo: Annotated[Optional[bool], Query()] = None,
    limit: Annotated[int, Query(ge=1, le=100)] = 10,
    offset: Annotated[int, Query(ge=0)] = 0
    ):
    service = CategoriaService(uow)
    return service.obtener_todos(activo=activo)

@categoria_router.post("/", response_model=CategoriaRead, status_code=201)
def crear_categoria(uow: UOW_Dep, categoria: CategoriaCreate):
    service = CategoriaService(uow)
    try :
        return service.crear_categoria(categoria)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error al crear la categoria: {e}")

@categoria_router.patch("/{id}", response_model=CategoriaRead)
def editar_categoria(uow: UOW_Dep, categoria: CategoriaUpdate, id: int = Path(gt=0)):
    service = CategoriaService(uow)
    try:
        return service.editar_categoria(id, categoria)
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"Categoria no encontrada: {e}")

@categoria_router.delete("/{id}", response_model=CategoriaRead)
def eliminar_categoria(uow: UOW_Dep, id: int = Path(gt=0)):
    service = CategoriaService(uow)
    try:
        return service.eliminar_categoria_logico(id)
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"Categoria no encontrada: {e}")