from typing import List, Optional, TYPE_CHECKING
from sqlmodel import Field, Relationship, SQLModel
from datetime import datetime
from app.modules.producto.model import ProductoCategoria
from app.modules.producto.model import Producto

class Categoria(SQLModel, table=True):
    __tablename__: str = 'categorias'

    id: Optional[int] = Field(default=None, primary_key=True)
    parent_id: Optional[int] = Field(default=None, foreign_key="categorias.id")
    nombre: str = Field(unique=True, nullable=False, max_length=100)
    descripcion: str
    imagen_url: str
    activo: bool = Field(default=True)
    productos: List["Producto"] = Relationship(back_populates="categorias", link_model=ProductoCategoria)
    created_at: datetime = Field(nullable=False)
    updated_at: datetime = Field(nullable=False)
    deleted_at: Optional[datetime] = Field(nullable=True)