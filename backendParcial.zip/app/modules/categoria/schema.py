from datetime import datetime
from typing import Optional
from sqlmodel import SQLModel, Field


class CategoriaCreate(SQLModel):
    nombre: str = Field(max_length=100)
    parent_id: Optional[int] = None
    descripcion: str
    imagen_url: str

class CategoriaRead(SQLModel):
    id: int
    parent_id: Optional[int]
    nombre: str
    descripcion: str
    imagen_url: str
    activo: bool
    created_at: datetime
    updated_at: datetime
    deleted_at: Optional[datetime]

class CategoriaReadShort(SQLModel):
    id: int
    nombre: str
    imagen_url: str

class CategoriaUpdate(CategoriaCreate):
    nombre: Optional[str] = Field(max_length=100)
    parent_id: Optional[int] = None
    descripcion: Optional[str] = None
    imagen_url: Optional[str] = None