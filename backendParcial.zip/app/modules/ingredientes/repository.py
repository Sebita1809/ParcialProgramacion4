from typing import List, Optional
from sqlmodel import Session, select
from datetime import datetime
from .model import Ingrediente
from .schema import IngredienteUpdate

class IngredienteRepository:

    def __init__(self, session: Session):
        self.session = session

    def get_all(self, activo: Optional[bool] = None) -> List[Ingrediente]:
        consulta = select(Ingrediente)
        if activo is not None:
            consulta = select(Ingrediente).where(Ingrediente.activo == activo)
        return self.session.exec(consulta).all()

    def get_all_short(self) -> List[Ingrediente]:
        consulta = select(Ingrediente)
        return self.session.exec(consulta).all()

    def get_by_id(self, id: int) -> Optional[Ingrediente]:
        ingrediente = self.session.get(Ingrediente, id)
        if not ingrediente:
            return None
        return ingrediente

    def create(self, ingrediente: Ingrediente) -> Ingrediente:
        self.session.add(ingrediente)
        return ingrediente

    def update(self, id: int, update: IngredienteUpdate) -> Optional[Ingrediente]:
        ingrediente = self.session.get(Ingrediente, id)
        if not ingrediente:
            return None

        for key, value in update.model_dump(exclude_unset=True).items():
            setattr(ingrediente, key, value)

        ingrediente.updated_at = datetime.now()

        self.session.add(ingrediente)

        return ingrediente

    def delete(self, id: int) -> Optional[Ingrediente]:
        ingrediente = self.session.get(Ingrediente, id)
        if not ingrediente:
            return None

        ingrediente.activo = False
        self.session.add(ingrediente)

        return ingrediente