from datetime import datetime
from typing import List, Optional

from app.modules.ingredientes.model import Ingrediente
from .schema import IngredienteCreate, IngredienteRead, IngredienteReadShort, IngredienteUpdate
from .model import Ingrediente
from app.core.unit_of_work import UnitOfWork

class IngredienteService:

    def __init__(self, uow: UnitOfWork) -> None:
        self.uow = uow

    def obtener_todos(self, activo: Optional[bool] = None) -> List[IngredienteRead]:
        with self.uow:
            return self.uow.ingredientes.get_all(activo=activo)

    def obtener_todos_short(self) -> List[IngredienteReadShort]:
        with self.uow:
            return self.uow.ingredientes.get_all_short()

    def crear_ingrediente(self, ingrediente: IngredienteCreate) -> IngredienteRead:
        with self.uow:
            datos_ingrediente = ingrediente.model_dump()
            nuevo_ingrediente = Ingrediente(**datos_ingrediente, created_at=datetime.now(), updated_at=datetime.now())
            self.uow.ingredientes.create(nuevo_ingrediente)

            self.uow.session.flush()
            self.uow.session.refresh(nuevo_ingrediente)

            return nuevo_ingrediente

    def editar_ingrediente(self, id: int, update: IngredienteUpdate) -> IngredienteRead:
        with self.uow:
            nuevo_ingrediente = self.uow.ingredientes.update(id, update)
            if not nuevo_ingrediente:
                return None

            self.uow.session.flush()
            self.uow.session.refresh(nuevo_ingrediente)

            return nuevo_ingrediente

    def eliminar_ingrediente_logico(self, id: int) -> IngredienteRead:
        with self.uow:
            ingrediente = self.uow.ingredientes.get_by_id(id)
            if not ingrediente:
                return None
            
            self.uow.ingredientes.delete(id)

            self.uow.session.flush()
            self.uow.session.refresh(ingrediente)

            return ingrediente
