from fastapi import APIRouter, HTTPException, Depends, Path, Query
from typing import Annotated, List, Optional
from app.core.unit_of_work import UnitOfWork
from app.modules.ingredientes.schema import IngredienteCreate, IngredienteRead, IngredienteUpdate
from app.modules.ingredientes.service import IngredienteService
UOW_Dep = Annotated[UnitOfWork, Depends(UnitOfWork)]

ingrediente_router = APIRouter(prefix="/ingredients", tags=["ingredients"])

@ingrediente_router.get("/", response_model=List[IngredienteRead])
def listar_ingredientes(
    uow: UOW_Dep,
    activo: Annotated[Optional[bool], Query()] = None,
    limit: Annotated[int, Query(ge=1, le=100)] = 10,
    offset: Annotated[int, Query(ge=0)] = 0
    ):
    service = IngredienteService(uow)
    try:
        return service.obtener_todos(activo=activo)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error al realizar la peticion: {e}")    

@ingrediente_router.post("/", response_model=IngredienteRead, status_code=201)
def crear_ingrediente(uow: UOW_Dep, ingrediente: IngredienteCreate):
    service = IngredienteService(uow)
    try:
        return service.crear_ingrediente(ingrediente)
    except:
        raise HTTPException(status_code=400, detail="Error al crear el ingrediente")

@ingrediente_router.patch("/{id}", response_model=IngredienteRead)
def editar_ingrediente(uow: UOW_Dep, ingrediente: IngredienteUpdate, id: int = Path(gt=0)):
    service = IngredienteService(uow)
    try:
        return service.editar_ingrediente(id, ingrediente)
    except:
        raise HTTPException(status_code=404, detail="Ingrediente no encontrado")

@ingrediente_router.delete("/{id}", response_model=IngredienteRead)
def eliminar_ingrediente(uow: UOW_Dep, id: int = Path(gt=0)):
    service = IngredienteService(uow)
    try: 
        return service.eliminar_ingrediente_logico(id)
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"Ingrediente no encontrado: {e}")