from typing import List, Optional, TYPE_CHECKING
from sqlmodel import Relationship, SQLModel, Field
from datetime import datetime
from app.modules.producto.model import ProductoIngrediente
from app.modules.producto.model import Producto

class Ingrediente(SQLModel, table=True):
    __tablename__: str = 'ingredientes'

    id: Optional[int] = Field(default=None, primary_key=True)
    nombre: str = Field(unique=True, nullable=False, max_length=100)
    descripcion: str
    es_alergeno: bool = Field(default=False, nullable=False)
    activo: bool = Field(default=True)
    productos: List["Producto"] = Relationship(back_populates="ingredientes", link_model=ProductoIngrediente)
    created_at: datetime = Field(nullable=False)
    updated_at: datetime = Field(nullable=False)