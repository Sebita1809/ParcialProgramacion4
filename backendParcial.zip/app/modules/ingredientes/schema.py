from datetime import datetime
from typing import Optional
from sqlmodel import SQLModel

class IngredienteCreate(SQLModel):
    nombre: str
    descripcion: str
    es_alergeno: bool

class IngredienteRead(SQLModel):
    id: int
    nombre: str
    descripcion: str
    es_alergeno: bool
    activo: bool
    created_at: datetime
    updated_at: datetime

class IngredienteUpdate(SQLModel):
    nombre: Optional[str] = None
    descripcion: Optional[str] = None
    es_alergeno: Optional[bool] = None

class IngredienteReadShort(SQLModel):
    id: int
    nombre: str