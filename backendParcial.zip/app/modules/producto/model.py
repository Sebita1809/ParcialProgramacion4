from decimal import Decimal
from typing import List, Optional, TYPE_CHECKING
from sqlmodel import CheckConstraint, Column, Field, ForeignKey, Integer, Numeric, Relationship, SQLModel, String, ARRAY
from datetime import datetime

if TYPE_CHECKING:
    from modules.categoria.model import Categoria
    from modules.ingredientes.model import Ingrediente

class ProductoIngrediente(SQLModel, table=True):
    __tablename__: str = 'producto_ingrediente'
    producto_id: int = Field(
        sa_column=Column(Integer, ForeignKey("productos.id", ondelete="CASCADE"), primary_key=True, nullable=False)
    )
    ingrediente_id: int = Field(
        sa_column=Column(Integer, ForeignKey("ingredientes.id", ondelete="CASCADE"), primary_key=True, nullable=False)
    )
    es_removible: bool = Field(default=False, nullable=False)

class ProductoCategoria(SQLModel, table=True):
    __tablename__: str = 'producto_categoria'
    producto_id: int = Field(
        sa_column=Column(Integer, ForeignKey("productos.id", ondelete="CASCADE"), primary_key=True, nullable=False)
    )
    categoria_id: int = Field(
        sa_column=Column(Integer, ForeignKey("categorias.id", ondelete="CASCADE"), primary_key=True, nullable=False)
    )
    es_principal: bool = Field(default=False, nullable=False)
    created_at: datetime = Field(default_factory=datetime.now, nullable=False)

class Producto(SQLModel, table=True):
    __tablename__: str = 'productos'

    id: Optional[int] = Field(default=None, primary_key=True)
    nombre: str = Field(nullable=False, max_length=150)
    descripcion: str
    precio_base: Decimal = Field(
        sa_column=Column(
            Numeric(10, 2),
            CheckConstraint("precio_base >= 0"),
            default=0,
            nullable=False
        )
    )
    imagenes_url: List[str] = Field(sa_column=Column(ARRAY(String)))
    stock_cantidad: int = Field(
        sa_column=Column(
            Integer,
            CheckConstraint("stock_cantidad >= 0"),
            default=0,
            nullable=False
        )
    )
    categorias: List["Categoria"] = Relationship(back_populates="productos", link_model=ProductoCategoria)
    ingredientes: List["Ingrediente"] = Relationship(back_populates="productos", link_model=ProductoIngrediente)
    disponible: bool = Field(default=True, nullable=False)
    created_at: datetime = Field(nullable=False)
    updated_at: datetime = Field(nullable=False)
    deleted_at: Optional[datetime] = Field(nullable=True)
    activo: bool = Field(default=True)
