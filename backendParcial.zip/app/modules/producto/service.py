from datetime import datetime
from typing import List
from app.core.unit_of_work import UnitOfWork
from .model import Producto
from .schema import CategoriaLink, IngredienteLink, ProductoCreate, ProductoRead, ProductoReadShort, ProductoUpdate, ListCategoriaRead, ListIngredienteRead

class ProductoService:

    def __init__(self, uow: UnitOfWork):
        self.uow = uow 

    def obtener_todos(self) -> List[ProductoRead]:
        with self.uow:                                                                                                                                                                                                         
          productos = self.uow.productos.get_all()
          resultado = []
          for producto in productos:
              cat_links, ing_links = self.uow.productos.get_links(producto.id) 
              resultado.append(ProductoRead(
                  **producto.model_dump(),
                    categorias=[ListCategoriaRead(id=c.categoria_id, nombre=categoria.nombre, es_principal=c.es_principal) for c, categoria in cat_links],
                  ingredientes=[ListIngredienteRead(id=i.ingrediente_id, nombre=ingrediente.nombre, es_removible=i.es_removible) for i, ingrediente in ing_links]
              ))
          return resultado

    def obtener_todos_short(self) -> List[ProductoReadShort]:
        with self.uow:
            return self.uow.productos.get_all_short()

    def crear_producto(self, producto: ProductoCreate) -> ProductoRead:
        with self.uow:

            datos_producto = producto.model_dump(exclude={"categorias", "ingredientes"})

            nuevo_producto = Producto(**datos_producto, created_at=datetime.now(), updated_at=datetime.now())

            self.uow.productos.crear(nuevo_producto)

            self.uow.session.flush()

            self.uow.productos.vincular_categorias(nuevo_producto.id, producto.categorias)
            self.uow.productos.vincular_ingredientes(nuevo_producto.id, producto.ingredientes)

            self.uow.session.flush()
            self.uow.session.refresh(nuevo_producto)

            categoria_links, ingrediente_links = self.uow.productos.get_links(nuevo_producto.id)

            return ProductoRead(
                **nuevo_producto.model_dump(),
                categorias=[ListCategoriaRead(id=c.categoria_id, nombre=cat.nombre, es_principal=c.es_principal) for c, cat in categoria_links],
                ingredientes=[ListIngredienteRead(id=i.ingrediente_id, nombre=ing.nombre, es_removible=i.es_removible) for i, ing in ingrediente_links]
            )

    def editar_producto(self, id: int, update: ProductoUpdate) -> ProductoRead:
        with self.uow:
            producto_nuevo = self.uow.productos.update(id, update)

            if not producto_nuevo:
                return None

            self.uow.session.flush()

            if update.categorias is not None:
                self.uow.productos.desvincular_categoria(producto_nuevo.id)
                self.uow.productos.vincular_categorias(producto_nuevo.id, update.categorias)

            if update.ingredientes is not None:
                self.uow.productos.desvincular_ingrediente(producto_nuevo.id)
                self.uow.productos.vincular_ingredientes(producto_nuevo.id, update.ingredientes)

            self.uow.session.flush()
            self.uow.session.refresh(producto_nuevo)

            categoria_links, ingrediente_links = self.uow.productos.get_links(producto_nuevo.id)

            return ProductoRead(
                **producto_nuevo.model_dump(),
                categorias=[ListCategoriaRead(id=c.categoria_id, nombre=cat.nombre, es_principal=c.es_principal) for c, cat in categoria_links],
                ingredientes=[ListIngredienteRead(id=i.ingrediente_id, nombre=ing.nombre, es_removible=i.es_removible) for i, ing in ingrediente_links]
            )

    def eliminar_producto_logico(self, id: int) -> ProductoRead:
        with self.uow:
            producto = self.uow.productos.delete(id)
            if not producto:
                return None

            self.uow.session.flush()
            self.uow.session.refresh(producto)

            categoria_links, ingrediente_links = self.uow.productos.get_links(producto.id)

            return ProductoRead(
                **producto.model_dump(),
                categorias=[ListCategoriaRead(id=c.categoria_id, nombre=cat.nombre, es_principal=c.es_principal) for c, cat in categoria_links],
                ingredientes=[ListIngredienteRead(id=i.ingrediente_id, nombre=ing.nombre, es_removible=i.es_removible) for i, ing in ingrediente_links]
            )