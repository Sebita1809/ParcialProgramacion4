from datetime import datetime
from sqlmodel import SQLModel, Field
from decimal import Decimal
from typing import List, Optional

class CategoriaLink(SQLModel):
    id: int
    es_principal: Optional[bool] = False

class IngredienteLink(SQLModel):
    id: int
    es_removible: Optional[bool]

class ListCategoriaRead(SQLModel):
    id: int
    nombre: str
    es_principal: bool

class ListIngredienteRead(SQLModel):
    id: int
    nombre: str
    es_removible: bool

class ProductoCreate(SQLModel):
    nombre: str
    descripcion: str
    precio_base: Decimal = Field (
        ge=0,
        max_digits=10,
        decimal_places=2
    )
    imagenes_url: List[str]
    stock_cantidad: int = Field(ge=0)
    categorias: List[CategoriaLink]
    ingredientes: List[IngredienteLink]

class ProductoUpdate(SQLModel):
    nombre: Optional[str] = None
    descripcion: Optional[str] = None
    precio_base: Optional[Decimal] = Field(default=None, ge=0, max_digits=10, decimal_places=2)
    imagenes_url: Optional[List[str]] = None
    stock_cantidad: Optional[int] = Field(default=None, ge=0)
    categorias: Optional[List[CategoriaLink]] = None
    ingredientes: Optional[List[IngredienteLink]] = None

class ProductoRead(SQLModel):
    id: int
    nombre: str
    descripcion: str
    precio_base: Decimal = Field (
        ge=0,
        max_digits=10,
        decimal_places=2
    )
    imagenes_url: List[str]
    stock_cantidad: int = Field(ge=0)
    categorias: List[ListCategoriaRead]
    ingredientes: List[ListIngredienteRead]
    disponible: bool
    created_at: datetime
    updated_at: datetime
    deleted_at: Optional[datetime] = None
    activo: bool 

class ProductoReadShort(SQLModel):
    id: int
    nombre: str
    descripcion: str