from fastapi import APIRouter, HTTPException, Depends, Path, Query
from typing import Annotated, List, Optional
from app.core.unit_of_work import UnitOfWork
from app.modules.producto.schema import ProductoCreate, ProductoRead, ProductoUpdate
from app.modules.producto.service import ProductoService

UOW_Dep = Annotated[UnitOfWork, Depends(UnitOfWork)]

producto_router = APIRouter(prefix="/products", tags=["Products"])

@producto_router.get("/", response_model=List[ProductoRead])
def listar_productos(
    uow: UOW_Dep,
    disponible: Annotated[Optional[bool], Query()] = None,
    limit: Annotated[int, Query(ge=1, le=100)] = 10,
    offset: Annotated[int, Query(ge=0)] = 0
    ):
    service = ProductoService(uow)
    return service.obtener_todos()

@producto_router.post("/", response_model=ProductoRead, status_code=201)
def crear_producto(uow: UOW_Dep, producto: ProductoCreate):
    service = ProductoService(uow)
    try:
        return service.crear_producto(producto)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error al crear el producto: {e}")

@producto_router.patch("/{id}", response_model=ProductoRead)
def editar_producto(uow: UOW_Dep, producto: ProductoUpdate, id: int = Path(gt=0)):
    service = ProductoService(uow)
    try:
        return service.editar_producto(id, producto)
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"Producto no encontrado {e}")

@producto_router.delete("/{id}", response_model=ProductoRead)
def eliminar_producto(uow: UOW_Dep, id: int = Path(gt=0)):
    service = ProductoService(uow)
    try:
        return service.eliminar_producto_logico(id)
    except:
        raise HTTPException(status_code=404, detail="Producto no encontrado")