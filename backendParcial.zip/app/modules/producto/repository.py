from datetime import datetime
from typing import List, Optional

from .schema import CategoriaLink, IngredienteLink, ProductoUpdate
from sqlmodel import Session, delete, select
from .model import Producto, ProductoCategoria, ProductoIngrediente

class ProductoRepository:

    def __init__(self, session: Session):
        self.session = session

    def get_all(self) -> List[Producto]:
        consulta = select(Producto)
        return self.session.exec(consulta).all()

    def get_all_short(self) -> List[Producto]:
        consulta = select(Producto)
        return self.session.exec(consulta).all()

    def get_by_id(self, id: int) -> Optional[Producto]:
        return self.session.get(Producto, id)

    def vincular_categorias(self, producto_id: int, categorias: List[CategoriaLink]):
        for items in categorias:
            nueva_relacion = ProductoCategoria(
                producto_id=producto_id,
                categoria_id=items.id,
                es_principal=items.es_principal,
                created_at=datetime.now()
            )
            self.session.add(nueva_relacion)

    def vincular_ingredientes(self, producto_id: int, ingredientes: List[IngredienteLink]):
        for items in ingredientes:
            nueva_relacion = ProductoIngrediente(
                producto_id=producto_id,
                ingrediente_id=items.id,
                es_removible=items.es_removible
            )
            self.session.add(nueva_relacion)

    def desvincular_categoria(self, producto_id: int):
        statement = delete(ProductoCategoria).where(ProductoCategoria.producto_id == producto_id)
        self.session.exec(statement)

    def desvincular_ingrediente(self, producto_id: int):
        statement = delete(ProductoIngrediente).where(ProductoIngrediente.producto_id == producto_id)
        self.session.exec(statement)

    def get_links(self, producto_id: int):
        from app.modules.categoria.model import Categoria
        from app.modules.ingredientes.model import Ingrediente

        categoria_links = self.session.exec(
            select(ProductoCategoria, Categoria).join(Categoria).where(ProductoCategoria.producto_id == producto_id)
        ).all()
        ingrediente_links = self.session.exec(
            select(ProductoIngrediente, Ingrediente).join(Ingrediente).where(ProductoIngrediente.producto_id == producto_id)
        ).all()
        return categoria_links, ingrediente_links

    def crear(self, producto: Producto) -> Producto:
        self.session.add(producto)
        return producto

    def update(self, id: int, update: ProductoUpdate) -> Optional[Producto]:
        producto = self.session.get(Producto, id)
        if not producto:
            return None

        for key, value in update.model_dump(
            exclude_unset=True,
            exclude={"categorias", "ingredientes"}).items():
            setattr(producto, key, value)

        producto.updated_at = datetime.now()

        self.session.add(producto)

        return producto

    def delete(self, id: int) -> Optional[Producto]:
        producto = self.session.get(Producto, id)
        if not producto:
            return None

        producto.disponible = False
        producto.deleted_at = datetime.now()

        self.session.add(producto)

        return producto
