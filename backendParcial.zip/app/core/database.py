from sqlmodel import create_engine, SQLModel, Session

DATABASE_URL = "postgresql://postgres:Sebita1809@localhost:5432/FoodStore"

engine = create_engine(
    DATABASE_URL,
    echo=True
)

def create_db_and_tables():
    SQLModel.metadata.create_all(engine)

def get_session():
    with Session(engine, expire_on_commit=False) as session:
        yield session 