from fastapi import Depends
from sqlmodel import Session
from app.core.database import get_session
from app.modules.categoria.repository import CategoriaRepository
from app.modules.ingredientes.repository import IngredienteRepository
from app.modules.producto.repository import ProductoRepository

class UnitOfWork:

    def __init__(self, session: Session = Depends(get_session)):
        self.session = session

    def __enter__(self):
        self.categorias = CategoriaRepository(self.session)
        self.ingredientes = IngredienteRepository(self.session)
        self.productos = ProductoRepository(self.session)

        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            self.session.rollback()
        else:
            self.session.commit()
        self.session.close()