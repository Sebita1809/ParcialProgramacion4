from fastapi import FastAPI
from contextlib import asynccontextmanager
from fastapi.middleware.cors import CORSMiddleware

from .core.database import create_db_and_tables
from .modules.categoria.router import categoria_router
from .modules.ingredientes.router import ingrediente_router
from .modules.producto.router import producto_router
from .modules.categoria.model import Categoria
from .modules.ingredientes.model import Ingrediente
from .modules.producto.model import Producto, ProductoCategoria, ProductoIngrediente

@asynccontextmanager
async def lifespan(app: FastAPI):

    create_db_and_tables()
    yield

app = FastAPI(
    titile="API Parcial - Programacion 4",
    descripcion="Concepto: CRUD de productos, categorias e ingredientes del proyecto FoodStore",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=['http://localhost:5173'],
    allow_methods=['*'],
    allow_headers=['*'],
)

app.include_router(producto_router)
app.include_router(categoria_router)
app.include_router(ingrediente_router)