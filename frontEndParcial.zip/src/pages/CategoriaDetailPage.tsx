import { useParams, useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { getCategorias } from '../services/CategoryService'
import NavBar from '../components/NavBar'
import SideBar from '../components/SideBar'

const CategoriaDetailPage = () => {
  const { id } = useParams()
  const navigate = useNavigate()

  const { data: categorias, isLoading } = useQuery({
    queryKey: ['categorias'],
    queryFn: getCategorias
  })

  if (isLoading) return <p>Cargando...</p>

  const categoria = categorias?.find(c => c.id === Number(id))

  if (!categoria) return <p>Categoría no encontrada</p>

  const padre = categoria.parent_id
    ? categorias?.find(c => c.id === categoria.parent_id)
    : null

  return (
    <div className='flex min-h-screen bg-gray-200'>
      <SideBar />
      <main className='flex-1'>
        <NavBar />
        <div className='max-w-2xl mx-auto mt-10 px-4'>

          <div className='flex items-center gap-2 mb-6'>
            <button
              onClick={() => navigate('/categorias')}
              className='text-gray-400 hover:text-orange-400 transition-colors text-sm font-semibold'
            >
              Categorías
            </button>
            {padre && (
              <>
                <span className='text-gray-400'>›</span>
                <span className='text-gray-400 text-sm font-semibold'>{padre.nombre}</span>
              </>
            )}
            <span className='text-gray-400'>›</span>
            <span className='text-orange-400 text-sm font-semibold'>{categoria.nombre}</span>
          </div>

          <div className='bg-white rounded-2xl shadow-md overflow-hidden'>
            <img
              src={categoria.imagen_url || 'https://as1.ftcdn.net/jpg/10/22/24/80/220_F_1022248039_7LDxHRi3Mlt9BK3wzLBUGZp9XAO1gt2s.jpg'}
              alt={categoria.nombre}
              className='w-full h-64 object-cover'
              onError={e => { (e.target as HTMLImageElement).src = 'https://as1.ftcdn.net/jpg/10/22/24/80/220_F_1022248039_7LDxHRi3Mlt9BK3wzLBUGZp9XAO1gt2s.jpg' }}
            />
            <div className='p-6 flex flex-col gap-4'>
              <h1 className='font-paytone text-3xl text-gray-800'>{categoria.nombre}</h1>
              <p className='text-gray-500'>{categoria.descripcion}</p>

              <div className='border-t pt-4 flex flex-col gap-2'>
                <p className='font-bebas text-gray-400'>
                  Creado: {categoria.created_at
                    ? new Date(categoria.created_at).toLocaleDateString('es-AR', {
                        day: '2-digit', month: '2-digit', year: '2-digit',
                        hour: '2-digit', minute: '2-digit'
                      })
                    : 'Sin fecha'}
                </p>
                <p className='font-bebas text-gray-400'>
                  Última modificación: {categoria.updated_at
                    ? new Date(categoria.updated_at).toLocaleDateString('es-AR', {
                        day: '2-digit', month: '2-digit', year: '2-digit',
                        hour: '2-digit', minute: '2-digit'
                      })
                    : 'Sin fecha'}
                </p>
              </div>
            </div>
          </div>

        </div>
      </main>
    </div>
  )
}

export default CategoriaDetailPage
