import { useParams } from 'react-router-dom'

const IngredienteDetailPage = () => {
  const { id } = useParams()

  return (
    <div>
      <p>Detalle ingrediente {id}</p>
    </div>
  )
}

export default IngredienteDetailPage
