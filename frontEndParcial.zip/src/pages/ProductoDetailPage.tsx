import { useParams, useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { getProductos } from '../services/ProductService'
import { getIngredientes } from '../services/IngredientService'
import NavBar from '../components/NavBar'
import SideBar from '../components/SideBar'
import useEmblaCarousel from 'embla-carousel-react'
import estrellaCompleta from '../assets/estrella (1).png'

const FALLBACK_IMG = 'https://as1.ftcdn.net/jpg/10/22/24/80/220_F_1022248039_7LDxHRi3Mlt9BK3wzLBUGZp9XAO1gt2s.jpg'

const ProductoDetailPage = () => {
  const { id } = useParams()
  const navigate = useNavigate()
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true })

  const { data: productos, isLoading } = useQuery({
    queryKey: ['productos'],
    queryFn: getProductos
  })

  const { data: ingredientes } = useQuery({
    queryKey: ['ingredientes'],
    queryFn: getIngredientes
  })

  if (isLoading) return <p>Cargando...</p>

  const producto = productos?.find(p => p.id === Number(id))

  if (!producto) return <p>Producto no encontrado</p>

  const esBestSeller = producto.categorias?.some(c => c.es_principal)
  const tieneAlergenos = producto.ingredientes?.some(i => {
    const ingredienteCompleto = ingredientes?.find(ing => ing.id === i.id)
    return ingredienteCompleto?.es_alergeno
  })

  return (
    <div className='flex min-h-screen bg-gray-200'>
      <SideBar />
      <main className='flex-1'>
        <NavBar />
        <div className='max-w-2xl mx-auto mt-10 px-4'>

          <div className='flex items-center gap-2 mb-6'>
            <button
              onClick={() => navigate('/productos')}
              className='text-gray-400 hover:text-orange-400 transition-colors text-sm font-semibold'
            >
              Productos
            </button>
            <span className='text-gray-400'>›</span>
            <span className='text-orange-400 text-sm font-semibold'>{producto.nombre}</span>
          </div>

          <div className='bg-white rounded-2xl shadow-md overflow-hidden'>

            <div className='relative'>
              <div className='overflow-hidden' ref={emblaRef}>
                <div className='flex'>
                  {producto.imagenes_url?.length > 0 ? (
                    producto.imagenes_url.map((img, index) => (
                      <div key={index} className='flex-none w-full'>
                        <img
                          src={img}
                          alt={producto.nombre}
                          className='w-full h-72 object-cover'
                          onError={e => { (e.target as HTMLImageElement).src = FALLBACK_IMG }}
                        />
                      </div>
                    ))
                  ) : (
                    <div className='flex-none w-full'>
                      <img src={FALLBACK_IMG} alt={producto.nombre} className='w-full h-72 object-cover' />
                    </div>
                  )}
                </div>
              </div>
              {producto.imagenes_url?.length > 1 && (
                <>
                  <button
                    onClick={() => emblaApi?.scrollPrev()}
                    className='absolute left-2 top-1/2 -translate-y-1/2 bg-black/40 text-white rounded-full w-8 h-8 flex items-center justify-center hover:bg-black/60'
                  >
                    ‹
                  </button>
                  <button
                    onClick={() => emblaApi?.scrollNext()}
                    className='absolute right-2 top-1/2 -translate-y-1/2 bg-black/40 text-white rounded-full w-8 h-8 flex items-center justify-center hover:bg-black/60'
                  >
                    ›
                  </button>
                </>
              )}
              <div className='absolute top-2 left-2 flex gap-2'>
                {esBestSeller && <img src={estrellaCompleta} className='w-8 h-8' />}
              </div>
              <div className='absolute top-2 right-2 flex flex-col gap-1'>
                {producto.disponible && (
                  <span className='bg-green-500 text-white text-xs font-bold px-2 py-1 rounded-full'>
                    ✓ Disponible
                  </span>
                )}
                {tieneAlergenos && (
                  <span className='bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full'>
                    ⚠ Contiene alérgenos
                  </span>
                )}
              </div>
            </div>

            <div className='p-6 flex flex-col gap-4'>
              <h1 className='font-paytone text-3xl text-gray-800'>{producto.nombre}</h1>
              <p className='text-gray-500'>{producto.descripcion}</p>

              <div className='flex gap-6'>
                <div>
                  <p className='font-bebas text-gray-400 text-sm'>Precio</p>
                  <p className='font-paytone text-orange-400 text-xl'>${producto.precio_base}</p>
                </div>
                <div>
                  <p className='font-bebas text-gray-400 text-sm'>Stock</p>
                  <p className='font-paytone text-gray-700 text-xl'>{producto.stock_cantidad}</p>
                </div>
              </div>

              {producto.categorias?.length > 0 && (
                <div className='border-t pt-4'>
                  <p className='font-bebas text-gray-400 text-sm mb-2'>Categorías</p>
                  <div className='flex flex-wrap gap-2'>
                    {producto.categorias.map(c => (
                      <span key={c.id} className='flex items-center gap-1 bg-orange-100 border border-orange-300 rounded-full px-3 py-1 text-sm text-orange-700 font-semibold'>
                        {c.nombre}
                        {c.es_principal && <img src={estrellaCompleta} className='w-3 h-3' />}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {producto.ingredientes?.length > 0 && (
                <div className='border-t pt-4'>
                  <p className='font-bebas text-gray-400 text-sm mb-2'>Ingredientes</p>
                  <div className='flex flex-wrap gap-2'>
                    {producto.ingredientes.map(i => (
                      <span key={i.id} className='flex items-center gap-1 bg-green-100 border border-green-300 rounded-full px-3 py-1 text-sm text-green-700 font-semibold'>
                        {i.nombre}
                        <span title={i.es_removible ? 'Removible' : 'No removible'}>
                          {i.es_removible ? '🔓' : '🔒'}
                        </span>
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <div className='border-t pt-4 flex flex-col gap-1'>
                <p className='font-bebas text-gray-400'>
                  Creado: {producto.created_at
                    ? new Date(producto.created_at).toLocaleDateString('es-AR', {
                        day: '2-digit', month: '2-digit', year: '2-digit',
                        hour: '2-digit', minute: '2-digit'
                      })
                    : 'Sin fecha'}
                </p>
                <p className='font-bebas text-gray-400'>
                  Última modificación: {producto.updated_at
                    ? new Date(producto.updated_at).toLocaleDateString('es-AR', {
                        day: '2-digit', month: '2-digit', year: '2-digit',
                        hour: '2-digit', minute: '2-digit'
                      })
                    : 'Sin fecha'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

export default ProductoDetailPage
