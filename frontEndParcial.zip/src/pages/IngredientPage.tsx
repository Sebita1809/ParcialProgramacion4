import { useState } from "react"
import NavBar from "../components/NavBar"
import SerachBar from "../components/SerachBar"
import SideBar from "../components/SideBar"
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'                                                                                                                                              
import { getIngredientes, createIngrediente, updateIngrediente, deleteIngrediente } from '../services/IngredientService'   
import Modal from "../components/Modal"
import Loader from "../components/Loader"
import IngredientForm from "../components/IngredientForm"
import IngredientCard from "../components/IngredientCard"
import type { Ingrediente } from "../types/Ingrediente"

const IngredientePage = () => {
    const [showModal, setShowModal] = useState(false)
    const [searchTerm, setSearchTerm] = useState('')
    const [selectId, setSelectId] = useState<number | null>(null)
    const [edittingIngredient, setEdittinIngredient] = useState<Ingrediente | null>(null)
    const queryClient = useQueryClient()
  
    const { data, isLoading, isError } = useQuery({
      queryKey: ['ingredientes'],
      queryFn: getIngredientes,
      staleTime: 1000 * 60 * 5
    })
    
    const createMutation = useMutation({
      mutationFn: (body: object) => createIngrediente(body),
      onSuccess: () => queryClient.invalidateQueries({ queryKey: ['ingredientes'] })
    })
  
    const updateMutation = useMutation({
      mutationFn: ({ id, body }: { id: number, body: object }) => updateIngrediente(id, body),
      onSuccess: () => queryClient.invalidateQueries({ queryKey: ['ingredientes'] })
    })
  
    const deleteMutation = useMutation({
      mutationFn: (id: number) => deleteIngrediente(id),
      onSuccess: () => queryClient.invalidateQueries({ queryKey: ['ingredientes'] })
    })
    if(isLoading){
      return <Loader />
    }
  
    if(isError){
      return <p>Error {isError}</p>
    }
    console.log(data)
    const filtered = data ? data.filter(c => c.activo && c.nombre.toLowerCase().includes(searchTerm.toLowerCase())                                                                                                                                                                
    ) : []
    const handleModal = () => {
      setShowModal(!showModal)
      setEdittinIngredient(null)
    }
    const handleDelete = async (id: number) => {
      deleteMutation.mutate(id)
    }
  
    return (
      <>
        <div className="flex min-h-screen bg-gray-200">
          <SideBar />
          <main className="flex-1" onClick={() => setSelectId(null)}>
            <NavBar/>
            <div className="flex flex-col md:flex-row justify-around mt-10 mb-10 items-center gap-4 px-4">
                <h2 className="text-4xl">Ingredientes</h2>
                <div className="flex gap-5">
                  <button className="border-2 border-blue-500 text-blue-500 p-3 rounded-2xl hover:bg-blue-50" onClick={e => { e.stopPropagation(); setEdittinIngredient(null); setShowModal(true) }}>Agregar ingrediente</button>
                  <SerachBar value={searchTerm} nombre="Buscar ingrediente" onChange={setSearchTerm}></SerachBar>
                </div>
            </div>
            <div className={`flex gap-3 flex-wrap justify-center`}>
                {data && filtered.map((ing) => {
                    return (
                      <IngredientCard
                        key={ing.id}
                        ingrediente={ing}
                        isSelected={selectId === ing.id}
                        anySelected={selectId !== null}
                        onSelect={() => setSelectId(ing.id)}
                        onEdit={(ing) => {setEdittinIngredient(ing); setShowModal(true)}}
                        onDelete={handleDelete}
                      />
                    );
                  })}   
            </div>
            {showModal && (
              <Modal onClose={() => setShowModal(false)}>
                <IngredientForm onClose={handleModal} edittingIngredient={edittingIngredient} onSubmit={(values) => {
                  if(edittingIngredient) {
                    updateMutation.mutate({id: edittingIngredient.id, body: values})
                  } else {
                    createMutation.mutate(values)
                  }
                }}/>
              </Modal>
            )}
          </main>
        </div>
      </>
      
    )
}

export default IngredientePage