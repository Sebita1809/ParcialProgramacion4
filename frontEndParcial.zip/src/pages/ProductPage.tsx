import { useState } from "react"
import NavBar from "../components/NavBar"
import SerachBar from "../components/SerachBar"
import SideBar from "../components/SideBar"
import Modal from "../components/Modal"
import Loader from "../components/Loader"
import type { Producto } from "../types/Producto"
import ProductCard from "../components/ProductCard"
import ProductForm from "../components/ProductForm"
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { getProductos, createProducto, updateProducto, deleteProducto } from "../services/ProductService"
import { getCategorias } from "../services/CategoryService"
import CustomSelect from "../components/CustomSelect"

const ProductPage = () => {
    const [showModal, setShowModal] = useState(false)
    const [searchTerm, setSearchTerm] = useState('')
    const [selectId, setSelectId] = useState<number | null>(null)
    const [edittingProduct, setEdittingProduct] = useState<Producto | null>(null)
    const [categoriaFiltro, setCategoriaFiltro] = useState<{ id: number, nombre: string } | null>(null)

    const queryClient = useQueryClient()

    const { data, isLoading, isError } = useQuery({
      queryKey: ['productos'],
      queryFn: getProductos,
      staleTime: 1000 * 60 * 5
    })

    const { data: categorias } = useQuery({
      queryKey: ['categorias'],
      queryFn: getCategorias
    })

    const createMutation = useMutation({
      mutationFn: (body: object) => createProducto(body),
      onSuccess: () => queryClient.invalidateQueries({ queryKey: ['productos'] })
    })

    const updateMutation = useMutation({
      mutationFn: ({ id, body }: { id: number, body: object }) => updateProducto(id, body),
      onSuccess: () => queryClient.invalidateQueries({ queryKey: ['productos'] })
    })

    const deleteMutation = useMutation({
      mutationFn: (id: number) => deleteProducto(id),
      onSuccess: () => queryClient.invalidateQueries({ queryKey: ['productos'] })
    })

    if(isLoading) return <Loader />
    if(isError) return <p>Error al cargar productos</p>

    const filtered = data ? data.filter(p => {
      const matchNombre = p.activo && p.nombre.toLowerCase().includes(searchTerm.toLowerCase())
      const matchCategoria = categoriaFiltro ? p.categorias?.some(c => c.id === categoriaFiltro.id) : true
      return matchNombre && matchCategoria
    }) : []

    const handleModal = () => {
      setShowModal(!showModal)
      setEdittingProduct(null)
    }

    const handleDelete = (id: number) => deleteMutation.mutate(id)

    return (
      <>
        <div className="flex min-h-screen bg-gray-200">
          <SideBar />
          <main className="flex-1" onClick={() => setSelectId(null)}>
            <NavBar/>
            <div className="flex flex-col md:flex-row justify-around mt-10 mb-4 items-center gap-4 px-4">
                <h2 className="text-4xl">Productos</h2>
                <div className="flex flex-col gap-2">
                  <div className="flex gap-5">
                    <button
                      className="border-2 border-blue-500 text-blue-500 p-3 rounded-2xl hover:bg-blue-50"
                      onClick={e => { e.stopPropagation(); setEdittingProduct(null); setShowModal(true) }}
                    >
                      Agregar Producto
                    </button>
                    <SerachBar value={searchTerm} nombre="Buscar producto" onChange={setSearchTerm} />
                  </div>
                  <div className="flex items-center gap-2 justify-end">
                    {categoriaFiltro && (
                      <div className='flex items-center gap-1 bg-orange-100 border border-orange-300 rounded-full px-3 py-1'>
                        <span className='text-sm text-orange-700 font-semibold'>{categoriaFiltro.nombre}</span>
                        <button
                          onClick={() => setCategoriaFiltro(null)}
                          className='text-orange-500 hover:text-red-500 font-bold text-xs ml-1 transition-colors'
                        >
                          ✕
                        </button>
                      </div>
                    )}
                    <div className='w-48'>
                      <CustomSelect
                        placeholder='Filtrar por categoría'
                        options={categorias?.filter(c => c.activo) ?? []}
                        onSelect={(id) => {
                          const cat = categorias?.find(c => c.id === id)
                          if (cat) setCategoriaFiltro({ id: cat.id, nombre: cat.nombre })
                        }}
                      />
                    </div>
                  </div>
                </div>
            </div>

            <div className='flex gap-3 flex-wrap justify-center'>
                {filtered.map((prod) => (
                  <ProductCard
                    key={prod.id}
                    producto={prod}
                    isSelected={selectId === prod.id}
                    anySelected={selectId !== null}
                    onSelect={() => setSelectId(prod.id)}
                    onEdit={(prod) => { setEdittingProduct(prod); setShowModal(true) }}
                    onDelete={handleDelete}
                  />
                ))}
            </div>
            {showModal && (
              <Modal onClose={() => setShowModal(false)}>
                <ProductForm
                  onClose={handleModal}
                  edittingProduct={edittingProduct}
                  onSubmit={async (values) => {
                    if (edittingProduct) {
                      await updateMutation.mutateAsync({ id: edittingProduct.id, body: values })
                    } else {
                      await createMutation.mutateAsync(values)
                    }
                  }}
                />
              </Modal>
            )}
          </main>
        </div>
      </>
    )
}

export default ProductPage
