import { useState } from "react"
import CategoryCard from "../components/CategoryCard"
import NavBar from "../components/NavBar"
import SerachBar from "../components/SerachBar"
import SideBar from "../components/SideBar"
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { getCategorias, createCategoria, updateCategoria, deleteCategoria } from '../services/CategoryService'      
import Modal from "../components/Modal"
import CategoryForm from "../components/CategoryForm"
import type { Categoria } from "../types/Category"
import Loader from "../components/Loader"

const CategoriaPage = () => {

    const [showModal, setShowModal] = useState(false)
    const [searchTerm, setSearchTerm] = useState('')
    const [selectId, setSelectId] = useState<number | null>(null)
    const [edittingCategory, setEdittinCategory] = useState<Categoria | null>(null)

    const { data, isLoading, isError } = useQuery({
      queryKey: ['categorias'],
      queryFn: getCategorias,
      staleTime: 1000 * 60 * 5
    })
    const queryClient = useQueryClient() 
    const createMutation = useMutation({
      mutationFn: (body: object) => createCategoria(body),
      onSuccess: () => queryClient.invalidateQueries({ queryKey: ['categorias'] })
    })
  
    const updateMutation = useMutation({
      mutationFn: ({ id, body }: { id: number, body: object }) => updateCategoria(id, body),
      onSuccess: () => queryClient.invalidateQueries({ queryKey: ['categorias'] })
    })
  
    const deleteMutation = useMutation({
      mutationFn: (id: number) => deleteCategoria(id),
      onSuccess: () => queryClient.invalidateQueries({ queryKey: ['categorias'] })
    })
    if(isLoading){
      return <Loader />
    }

    if(isError){
      return <p>Error {isError}</p>
    }
    console.log(data)
    const filtered = data ? data.filter(c => c.activo && c.nombre.toLowerCase().includes(searchTerm.toLowerCase())                                                                                                                                                                
    ) : []
    const handleModal = () => {
      setShowModal(!showModal)
      setEdittinCategory(null)
    }
    const handleDelete = (id: number) => deleteMutation.mutate(id)

    return (
      <>
        <div className="flex min-h-screen bg-gray-200">
          <SideBar />
          <main className="flex-1" onClick={() => setSelectId(null)}>
            <NavBar/>
            <div className="flex flex-col md:flex-row justify-around mt-10 mb-10 items-center gap-4 px-4">
                <h2 className="text-4xl">Categorias</h2>
                <div className="flex gap-5">
                  <button className="border-2 border-blue-500 text-blue-500 p-3 rounded-2xl hover:bg-blue-50" onClick={e => {e.stopPropagation; setShowModal(true)}}>Agregar categoria</button>
                  <SerachBar value={searchTerm} nombre="Buscar categoria" onChange={setSearchTerm}></SerachBar>
                </div>
            </div>
            <div className={`flex gap-3 flex-wrap justify-center`}>
                {data && filtered.map((cat) => {
                    const padre = filtered.find(c => c.id === cat.parent_id);
                    
                    return (
                        <CategoryCard
                          key={cat.id}
                          categoria={cat}
                          nombrePadre={padre ? padre.nombre : null}
                          isSelected={selectId === cat.id}
                          anySelected={selectId !== null}
                          onSelect={() => setSelectId(cat.id)}
                          onEdit={(categoria) => { setEdittinCategory(categoria); setShowModal(true) }}
                          onDelete={handleDelete}
                        />
                    );
                  })}   
            </div>
            {showModal && (
              <Modal onClose={() => setShowModal(false)}>
                <CategoryForm
                  onClose={handleModal}
                  categorias={data ?? []}
                  edittingCategoria={edittingCategory}
                  onSubmit={(values) => {
                    if (edittingCategory) {
                      updateMutation.mutate({ id: edittingCategory.id, body: values })
                    } else {
                      createMutation.mutate(values)
                    }
                  }}
                />
              </Modal>
            )}
          </main>
        </div>
      </>
    )
}

export default CategoriaPage