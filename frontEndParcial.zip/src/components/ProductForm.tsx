import { useState } from 'react'
import type { SubmitEventHandler } from 'react'
import useForm from '../hooks/CustomForm'
import type { Producto } from '../types/Producto'
import { useQuery } from '@tanstack/react-query'
import { getCategorias } from '../services/CategoryService'
import { getIngredientes } from '../services/IngredientService'
import estrellaVacia from '../assets/estrella.png'
import CustomSelect from './CustomSelect'
import estrellaLlena from '../assets/estrella (1).png'

type CategoriaSeleccionada = {
  id: number
  nombre: string
  es_principal: boolean
}

type IngredienteSeleccionado = {
  id: number
  nombre: string
  es_removible: boolean
}

type Props = {
  onClose: () => void
  edittingProduct: Producto | null
  onSubmit: (values: object) => void
}

const ProductForm = ({ onClose, edittingProduct, onSubmit }: Props) => {

  const { data: categorias } = useQuery({
    queryKey: ['categorias'],
    queryFn: getCategorias
  })

  const { data: ingredientes } = useQuery({
    queryKey: ['ingredientes'],
    queryFn: getIngredientes
  })

  const [ingredientesSeleccionados, setIngredientesSeleccionados] = useState<IngredienteSeleccionado[]>(
    edittingProduct?.ingredientes?.map(i => ({ id: i.id, nombre: i.nombre, es_removible: i.es_removible })) ?? []
  )

  const handleAddIngrediente = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const id = Number(e.target.value)
    const ingrediente = ingredientes?.find(i => i.id === id)
    if (!ingrediente) return
    if (ingredientesSeleccionados.some(i => i.id === id)) return
    setIngredientesSeleccionados(prev => [...prev, { id, nombre: ingrediente.nombre, es_removible: false }])
    e.target.value = ''
  }

  const handleRemoveIngrediente = (id: number) => {
    setIngredientesSeleccionados(prev => prev.filter(i => i.id !== id))
  }

  const handleToggleRemovible = (id: number) => {
    setIngredientesSeleccionados(prev =>
      prev.map(i => i.id === id ? { ...i, es_removible: !i.es_removible } : i)
    )
  }

  const { values, handleChange, reset } = useForm({
    nombre: edittingProduct?.nombre ?? '',
    descripcion: edittingProduct?.descripcion ?? '',
    precio_base: edittingProduct?.precio_base ?? '',
    stock_cantidad: edittingProduct?.stock_cantidad ?? '',
    disponible: edittingProduct?.disponible ?? true,
  })

  const [imagenUrl, setImagenUrl] = useState('')
  const [imagenesUrl, setImagenesUrl] = useState<string[]>(
    edittingProduct?.imagenes_url ?? []
  )

  const handleAddImagen = () => {
    if (!imagenUrl.trim()) return
    if (imagenesUrl.includes(imagenUrl)) return
    setImagenesUrl(prev => [...prev, imagenUrl.trim()])
    setImagenUrl('')
  }

  const handleRemoveImagen = (url: string) => {
    setImagenesUrl(prev => prev.filter(i => i !== url))
  }

  const [categoriasSeleccionadas, setCategoriasSeleccionadas] = useState<CategoriaSeleccionada[]>(
    edittingProduct?.categorias?.map(c => ({ id: c.id, nombre: c.nombre, es_principal: c.es_principal })) ?? []
  )

  const handleAddCategoria = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const id = Number(e.target.value)
    const categoria = categorias?.find(c => c.id === id)
    if (!categoria) return
    if (categoriasSeleccionadas.some(c => c.id === id)) return
    setCategoriasSeleccionadas(prev => [...prev, { id, nombre: categoria.nombre, es_principal: false }])
    e.target.value = ''
  }

  const handleRemoveCategoria = (id: number) => {
    setCategoriasSeleccionadas(prev => prev.filter(c => c.id !== id))
  }

  const handleTogglePrincipal = (id: number) => {
    setCategoriasSeleccionadas(prev =>
      prev.map(c => c.id === id ? { ...c, es_principal: !c.es_principal } : c)
    )
  }

  const handleSubmit: SubmitEventHandler<HTMLFormElement> = async (e) => {
    e.preventDefault()
    await onSubmit({ ...values, imagenes_url: imagenesUrl, categorias: categoriasSeleccionadas, ingredientes: ingredientesSeleccionados })
    reset()
    onClose()
  }

  return (
    <form onSubmit={handleSubmit} className='flex flex-col gap-4'>
      <h2 className='font-paytone text-xl text-gray-800'>
        {edittingProduct ? 'Editar Producto' : 'Nuevo Producto'}
      </h2>

      <input
        type='text'
        placeholder='Nombre'
        value={values.nombre}
        onChange={e => handleChange('nombre', e.target.value)}
        className='border-2 border-gray-200 rounded-xl px-4 py-2 focus:outline-none focus:border-orange-400 transition-colors'
      />

      <input
        type='text'
        placeholder='Descripción'
        value={values.descripcion}
        onChange={e => handleChange('descripcion', e.target.value)}
        className='border-2 border-gray-200 rounded-xl px-4 py-2 focus:outline-none focus:border-orange-400 transition-colors'
      />

      <div className='flex gap-2'>
        <input
          type='text'
          placeholder='URL de imagen'
          value={imagenUrl}
          onChange={e => setImagenUrl(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), handleAddImagen())}
          className='border-2 border-gray-200 rounded-xl px-4 py-2 flex-1 focus:outline-none focus:border-orange-400 transition-colors'
        />
        <button
          type='button'
          onClick={handleAddImagen}
          className='bg-orange-400 text-white px-4 rounded-xl font-semibold hover:bg-orange-500 transition-colors'
        >
          +
        </button>
      </div>

      {imagenesUrl.length > 0 && (
        <div className='flex flex-wrap gap-2'>
          {imagenesUrl.map((url, index) => (
            <div key={index} className='flex items-center gap-1 bg-blue-100 border border-blue-300 rounded-full px-3 py-1'>
              <span className='text-sm text-blue-700 font-semibold truncate max-w-32'>Imagen {index + 1}</span>
              <button
                type='button'
                onClick={() => handleRemoveImagen(url)}
                className='text-blue-500 hover:text-red-500 font-bold text-xs transition-colors'
              >
                ✕
              </button>
            </div>
          ))}
        </div>
      )}

      <div className='flex gap-3'>
        <input
          type='number'
          placeholder='Precio base'
          value={values.precio_base}
          onChange={e => handleChange('precio_base', e.target.value)}
          className='border-2 border-gray-200 rounded-xl px-4 py-2 w-1/2 focus:outline-none focus:border-orange-400 transition-colors'
        />
        <input
          type='number'
          placeholder='Stock'
          value={values.stock_cantidad}
          onChange={e => handleChange('stock_cantidad', e.target.value)}
          className='border-2 border-gray-200 rounded-xl px-4 py-2 w-1/2 focus:outline-none focus:border-orange-400 transition-colors'
        />
      </div>
      <div className='flex text-gray-400 text-sm mt-1 justify-between pl-3 pr-3 h-5'>
        <p>Producto mas vendido</p>
        <img src={estrellaVacia} alt="" />
      </div>
      <CustomSelect
        placeholder='Seleccioná una categoría'
        options={categorias?.filter(c => c.activo) ?? []}
        onSelect={(id) => {
          const categoria = categorias?.find(c => c.id === id)
          if (!categoria) return
          if (categoriasSeleccionadas.some(c => c.id === id)) return
          setCategoriasSeleccionadas(prev => [...prev, { id, nombre: categoria.nombre, es_principal: false }])
        }}
      />

      {categoriasSeleccionadas.length > 0 && (
        <div className='flex flex-wrap gap-2'>
          {categoriasSeleccionadas.map(c => (
            <div key={c.id} className='flex items-center gap-1 bg-green-100 border border-green-300 rounded-full px-3 py-1'>
              <span className='text-sm text-green-700 font-semibold'>{c.nombre}</span>
              <button
                type='button'
                onClick={() => handleTogglePrincipal(c.id)}
                className='hover:scale-110 transition-transform'
                title='Marcar como best seller'
              >
                <img src={c.es_principal ? estrellaLlena : estrellaVacia} className='w-4 h-4' />
              </button>
              <button
                type='button'
                onClick={() => handleRemoveCategoria(c.id)}
                className='text-orange-500 hover:text-red-500 font-bold text-xs transition-colors'
              >
                ✕
              </button>
            </div>
          ))}
        </div>
      )}

      <div className='flex text-gray-400 text-sm justify-between pl-3 pr-3 h-5'>
        <p>Ingrediente removible</p>
        <span>🔓</span>
      </div>

      <CustomSelect
        placeholder='Seleccioná un ingrediente'
        options={ingredientes?.filter(i => i.activo) ?? []}
        onSelect={(id) => {
          const ingrediente = ingredientes?.find(i => i.id === id)
          if (!ingrediente) return
          if (ingredientesSeleccionados.some(i => i.id === id)) return
          setIngredientesSeleccionados(prev => [...prev, { id, nombre: ingrediente.nombre, es_removible: false }])
        }}
      />

      {ingredientesSeleccionados.length > 0 && (
        <div className='flex flex-wrap gap-2'>
          {ingredientesSeleccionados.map(i => (
            <div key={i.id} className='flex items-center gap-1 bg-green-100 border border-green-300 rounded-full px-3 py-1'>
              <span className='text-sm text-green-700 font-semibold'>{i.nombre}</span>
              <button
                type='button'
                onClick={() => handleToggleRemovible(i.id)}
                className='hover:scale-110 transition-transform'
                title='Marcar como removible'
              >
                {i.es_removible ? '🔓' : '🔒'}
              </button>
              <button
                type='button'
                onClick={() => handleRemoveIngrediente(i.id)}
                className='text-orange-500 hover:text-red-500 font-bold text-xs transition-colors'
              >
                ✕
              </button>
            </div>
          ))}
        </div>
      )}

      <div className='flex gap-3 mt-2'>
        <button
          type='button'
          onClick={onClose}
          className='flex-1 border-2 border-gray-300 text-gray-500 py-2 rounded-xl font-semibold hover:bg-gray-50 transition-colors'
        >
          Cancelar
        </button>
        <button
          type='submit'
          className='flex-1 bg-orange-400 text-white py-2 rounded-xl font-semibold hover:bg-orange-500 transition-colors'
        >
          {edittingProduct ? 'Guardar' : 'Crear'}
        </button>
      </div>
    </form>
  )
}

export default ProductForm
