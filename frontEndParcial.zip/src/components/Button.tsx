type Props = {
    color: string
    texto: string
}

const Button = (props: Props) => {
  return (
    <button className="">{props.texto}</button>
  )
}

export default Button