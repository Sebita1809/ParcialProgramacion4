import React from 'react'

type Props = {
    onClose: () => void
    children: React.ReactNode
}

const Modal = ({onClose, children}: Props) => {
  return (
    <div
        onClick={onClose} className='fixed inset-0 bg-black/50 flex items-center justify-center z-50'>
        <div
            onClick={e => e.stopPropagation()} className='bg-white rounded-2xl p-6 w-full mx-4 md:w-96 shadow-2xl max-h-[90vh] overflow-y-auto'>
            {children}
        </div>
    </div>
  )
}

export default Modal