import type { Ingrediente } from '../types/Ingrediente'

type Props = {
  ingrediente: Ingrediente
  isSelected: boolean
  anySelected: boolean
  onSelect: () => void
  onEdit: (ingrediente: Ingrediente) => void
  onDelete: (id: number) => void
}

const IngredientCard = (props: Props) => {

  return (
    <div
      onClick={e => { e.stopPropagation(); props.onSelect() }}
      className={`flex flex-col bg-blue-100 rounded-2xl shadow-md overflow-hidden cursor-pointer transition-all duration-300 ${props.isSelected ? 'ring-2 ring-orange-400 relative z-10 -translate-y-4 w-72 md:w-80 shadow-2xl' : props.anySelected ? 'w-36 md:w-48 opacity-40 blur-sm scale-95' : 'w-36 md:w-48 hover:shadow-xl hover:-translate-y-1'}`}
    >
      <div className='flex flex-1 flex-col gap-2 p-3 text-center h-fit'>
        <h3 className='font-paytone text-gray-800 text-lg leading-tight'>{props.ingrediente.nombre}</h3>
        <p className='text-gray-400 text-xs'>{props.ingrediente.descripcion}</p>

        {props.isSelected && (
          <div className='flex flex-col gap-1 mt-2 text-left border-t pt-2'>
            <p className='font-bebas text-gray-500'>
              Creado: {props.ingrediente.created_at
                ? new Date(props.ingrediente.created_at).toLocaleDateString('es-AR', {
                    day: '2-digit', month: '2-digit', year: '2-digit',
                    hour: '2-digit', minute: '2-digit'
                  })
                : 'Sin fecha'}
            </p>
            <p className='font-bebas text-gray-500'>
              Última edición: {props.ingrediente.updated_at
                ? new Date(props.ingrediente.updated_at).toLocaleDateString('es-AR', {
                    day: '2-digit', month: '2-digit', year: '2-digit',
                    hour: '2-digit', minute: '2-digit'
                  })
                : 'Sin fecha'}
            </p>
            <div className='flex items-center gap-2 mt-1'>
              <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${props.ingrediente.es_alergeno ? 'bg-red-100 text-red-500' : 'bg-green-100 text-green-500'}`}>
                {props.ingrediente.es_alergeno ? '⚠ Alérgeno' : '✓ No alérgeno'}
              </span>
            </div>
          </div>
        )}

        <div className='flex gap-2 mt-auto'>
          <button
            onClick={e => { e.stopPropagation(); props.onEdit(props.ingrediente) }}
            className='flex-1 text-orange-500 border-2 border-orange-400 py-1 rounded-lg text-sm font-semibold hover:bg-orange-50 transition-colors'
          >
            Editar
          </button>
          <button
            onClick={e => { e.stopPropagation(); props.onDelete(props.ingrediente.id) }}
            className='flex-1 text-red-500 border-2 border-red-400 py-1 rounded-lg text-sm font-semibold hover:bg-red-50 transition-colors'
          >
            Borrar
          </button>
        </div>
      </div>
    </div>
  )
}

export default IngredientCard
