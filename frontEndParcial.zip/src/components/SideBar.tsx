import { useState } from 'react'
import { Link } from 'react-router-dom'

const SideBar = () => {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <>
      {/* Sidebar desktop */}
      <div className={`hidden md:flex flex-col bg-gray-300 transition-all duration-300 ${isOpen ? 'w-52' : 'w-14'}`}>
        <button onClick={() => setIsOpen(!isOpen)} className='flex items-center justify-center w-full p-3 hover:bg-gray-100 rounded-lg'>
          {isOpen ? '✕' : '☰'}
        </button>
        <nav className='flex flex-col gap-1 p-2'>
          <Link to="/categorias" className='flex items-center p-2 gap-3 hover:bg-gray-100 rounded-lg'>
            <span className='text-xl'>🍔</span>
            {isOpen && <span className='text-sm font-semibold text-gray-700'>Categorías</span>}
          </Link>
          <Link to="/productos" className='flex items-center gap-3 p-2 hover:bg-gray-100 rounded-lg'>
            <span className='text-xl'>📦</span>
            {isOpen && <span className='text-sm font-semibold text-gray-700'>Productos</span>}
          </Link>
          <Link to="/ingredientes" className='flex items-center gap-3 p-2 hover:bg-gray-100 rounded-lg'>
            <span className='text-xl'>🌿</span>
            {isOpen && <span className='text-sm font-semibold text-gray-700'>Ingredientes</span>}
          </Link>
        </nav>
      </div>

      {/* Botón hamburguesa mobile */}
      <button
        onClick={() => setIsOpen(true)}
        className='md:hidden fixed top-3 left-3 z-50 bg-white rounded-full w-10 h-10 flex items-center justify-center shadow-md'
      >
        ☰
      </button>

      {/* Overlay mobile */}
      {isOpen && (
        <div className='md:hidden fixed inset-0 z-40 flex'>
          <div className='bg-gray-300 w-64 flex flex-col p-4 gap-2'>
            <button onClick={() => setIsOpen(false)} className='self-end text-gray-600 text-xl mb-4'>✕</button>
            <Link to="/categorias" onClick={() => setIsOpen(false)} className='flex items-center gap-3 p-3 hover:bg-gray-100 rounded-lg'>
              <span className='text-xl'>🍔</span>
              <span className='text-sm font-semibold text-gray-700'>Categorías</span>
            </Link>
            <Link to="/productos" onClick={() => setIsOpen(false)} className='flex items-center gap-3 p-3 hover:bg-gray-100 rounded-lg'>
              <span className='text-xl'>📦</span>
              <span className='text-sm font-semibold text-gray-700'>Productos</span>
            </Link>
            <Link to="/ingredientes" onClick={() => setIsOpen(false)} className='flex items-center gap-3 p-3 hover:bg-gray-100 rounded-lg'>
              <span className='text-xl'>🌿</span>
              <span className='text-sm font-semibold text-gray-700'>Ingredientes</span>
            </Link>
          </div>
          <div className='flex-1 bg-black/40' onClick={() => setIsOpen(false)} />
        </div>
      )}
    </>
  )
}

export default SideBar
