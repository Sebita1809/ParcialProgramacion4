import type { SubmitEventHandler } from 'react';
import useForm from '../hooks/CustomForm'
import type { Ingrediente } from '../types/Ingrediente'

type Props = {
    onClose: () => void
    edittingIngredient: Ingrediente | null
    onSubmit: (value) => void
}

const IngredientForm = ({onClose,  edittingIngredient, onSubmit}: Props) => {
    const {values, handleChange, reset} = useForm({
        nombre: edittingIngredient?.nombre ?? '',
        descripcion: edittingIngredient?.descripcion ?? '',
        es_alergeno: edittingIngredient?.es_alergeno ?? false
    })
    const handleSubmit : SubmitEventHandler<HTMLFormElement> = async (e) => {
        e.preventDefault()
        onSubmit(values)
        reset()
        onClose()
    }
    return (
        <form onSubmit={handleSubmit} className='flex flex-col gap-4'>
            <h2 className='font-paytone text-xl text-gray-800'>{ edittingIngredient ? 'Editar Ingrediente' : 'Nuevo Ingrediente'}</h2>
            <input
            type='text'
            placeholder='Nombre'
            value={values.nombre}
            onChange={e => handleChange('nombre', e.target.value)}
            className='border-2 border-gray-200 rounded-xl px-4 py-2 focus:outline-none focus:border-orange-400 transition-colors'
            />

            <input
            type='text'
            placeholder='Descripción'
            value={values.descripcion}
            onChange={e => handleChange('descripcion', e.target.value)}
            className='border-2 border-gray-200 rounded-xl px-4 py-2 focus:outline-none focus:border-orange-400 transition-colors'
            />

            <div className='flex items-center gap-2 ml-2'>
            <input                                                                                                                                                                                                                         type='checkbox'                                                                                                                                                                                                        
            id='es_alergeno'                                                                                                                                                                                                       
            checked={values.es_alergeno}                                                                                                                                                                                           
            onChange={e => handleChange('es_alergeno', e.target.checked)}
            />
                <label htmlFor='subcategoria' className='text-sm text-gray-600'>
                    ¿Es alergeno?
                </label>
            </div>

            <div className='flex gap-3 mt-2'>
            <button
                type='button'
                onClick={onClose}
                className='flex-1 border-2 border-gray-300 text-gray-500 py-2 rounded-xl font-semibold hover:bg-gray-50 transition-colors'
            >
                Cancelar
            </button>
            <button
                type='submit'
                className='flex-1 bg-orange-400 text-white py-2 rounded-xl font-semibold hover:bg-orange-500 transition-colors'
            >
                {edittingIngredient ? 'Guardar' : 'Crear'}
            </button>
            </div>
        </form>
    )
}

export default IngredientForm