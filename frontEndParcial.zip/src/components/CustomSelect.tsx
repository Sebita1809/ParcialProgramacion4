import { useState, useRef, useEffect } from 'react'

type Option = {
  id: number
  nombre: string
}

type Props = {
  options: Option[]
  placeholder: string
  onSelect: (id: number) => void
}

const CustomSelect = ({ options, placeholder, onSelect }: Props) => {
  const [isOpen, setIsOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setIsOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const handleSelect = (id: number) => {
    onSelect(id)
    setIsOpen(false)
  }

  return (
    <div className='relative' ref={ref}>
      <button
        type='button'
        onClick={() => setIsOpen(!isOpen)}
        className='w-full flex items-center justify-between border-2 border-gray-200 rounded-xl px-4 py-2 focus:outline-none focus:border-orange-400 transition-colors bg-white hover:border-orange-300'
      >
        <span className='text-gray-400 text-sm'>{placeholder}</span>
        <span className={`text-gray-400 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`}>▼</span>
      </button>

      {isOpen && (
        <div className='absolute z-50 w-full mt-1 bg-white border-2 border-gray-200 rounded-xl shadow-lg overflow-hidden'>
          {options.length === 0 ? (
            <p className='text-gray-400 text-sm px-4 py-3'>No hay opciones disponibles</p>
          ) : (
            options.map(option => (
              <button
                key={option.id}
                type='button'
                onClick={() => handleSelect(option.id)}
                className='w-full text-left px-4 py-2 text-sm text-gray-700 font-semibold hover:bg-orange-50 hover:text-orange-500 transition-colors'
              >
                {option.nombre}
              </button>
            ))
          )}
        </div>
      )}
    </div>
  )
}

export default CustomSelect
