import { useState } from "react"
import type {FC} from 'react'

type Props = {
    value: string
    nombre: string
    onChange: (value: string) => void
}

const SerachBar: FC<Props> = (props: Props) => {

    const [search, setSearch] = useState('')

    return (
        <input 
            type="text" 
            placeholder={props.nombre}
            value={props.value}
            onChange={e => props.onChange(e.target.value)}
            className='border-2 border-gray-300 rounded-xl px-4 py-2 w-72 focus:outline-none focus:border-orange-400 transition-colors'/>
    )
}

export default SerachBar