const Loader = () => {
  return (
        <div className="flex justify-center items-center min-h-screen">
            <img src="https://cdn.dribbble.com/userupload/41870803/file/original-97410e04c492679fff3e75505987f89a.gif" alt="" />
        </div>
  )
}

export default Loader