import { useState } from 'react'
import type { SubmitEventHandler   } from 'react';
import useForm from '../hooks/CustomForm'
import CustomSelect from './CustomSelect'
import type { Categoria } from '../types/Category'

type Props = {
    onClose: () => void
    categorias: Categoria[]
    edittingCategoria: Categoria | null
    onSubmit: (value: object) => void
}

const CategoryForm = ({onClose, categorias, edittingCategoria, onSubmit}: Props) => {
    const [isSubCategoria, setIsSubCategoria] = useState(false)
    const {values, handleChange, reset} = useForm({
        nombre: edittingCategoria?.nombre ?? '',
        descripcion: edittingCategoria?.descripcion ?? '',
        imagen_url: edittingCategoria?.imagen_url ?? '',
        parent_id: edittingCategoria?.parent_id ?? null as number | null
    })
    const handleSubmit : SubmitEventHandler<HTMLFormElement> = async (e) => {
        e.preventDefault()
        onSubmit(values)
        reset()
        onClose()
    }
    return (
        <form onSubmit={handleSubmit} className='flex flex-col gap-4'>
            <h2 className='font-paytone text-xl text-gray-800'>{ edittingCategoria ? 'Editar Categoría' : 'Nueva Categoria'}</h2>
            <input
            type='text'
            placeholder='Nombre'
            value={values.nombre}
            onChange={e => handleChange('nombre', e.target.value)}
            className='border-2 border-gray-200 rounded-xl px-4 py-2 focus:outline-none focus:border-orange-400 transition-colors'
            />

            <input
            type='text'
            placeholder='Descripción'
            value={values.descripcion}
            onChange={e => handleChange('descripcion', e.target.value)}
            className='border-2 border-gray-200 rounded-xl px-4 py-2 focus:outline-none focus:border-orange-400 transition-colors'
            />

            <input
            type='text'
            placeholder='URL de imagen'
            value={values.imagen_url}
            onChange={e => handleChange('imagen_url', e.target.value)}
            className='border-2 border-gray-200 rounded-xl px-4 py-2 focus:outline-none focus:border-orange-400 transition-colors'
            />

            <div className='flex items-center gap-2'>
            <input
                type='checkbox'
                id='subcategoria'
                checked={isSubCategoria}
                onChange={e => {
                setIsSubCategoria(e.target.checked)
                handleChange('parent_id', null)
                }}
            />
            <label htmlFor='subcategoria' className='text-sm text-gray-600'>
                ¿Es subcategoría?
            </label>
            </div>

            { isSubCategoria && (
              <CustomSelect
                placeholder='Seleccioná una categoría padre'
                options={categorias.filter(c => c.parent_id === null && c.activo)}
                onSelect={(id) => handleChange('parent_id', id)}
              />
            )}

            <div className='flex gap-3 mt-2'>
            <button
                type='button'
                onClick={onClose}
                className='flex-1 border-2 border-gray-300 text-gray-500 py-2 rounded-xl font-semibold hover:bg-gray-50 transition-colors'
            >
                Cancelar
            </button>
            <button
                type='submit'
                className='flex-1 bg-orange-400 text-white py-2 rounded-xl font-semibold hover:bg-orange-500 transition-colors'
            >
                {edittingCategoria ? 'Guardar' : 'Crear'}
            </button>
            </div>
        </form>
    )
}

export default CategoryForm