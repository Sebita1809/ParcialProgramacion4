import logoComida from '../assets/comida.png'
const NavBar = () => {
  return (
      <nav className="sticky top-0 z-50 bg-blue-400/20 backdrop-blur-md border-b border-white/30 shadow-sm">
        <div className="flex flex-row items-center bg-blue-200 sticky top-0">
            <img src={logoComida} alt="" className=" h-12 m-2.5" />
            <p className="text-3xl ml-2.5">Food Store</p>
        </div>
      </nav>
        
  )
}

export default NavBar