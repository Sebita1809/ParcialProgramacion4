import type { Producto } from '../types/Producto'
import estrellaVacia from '.././assets/estrella.png'
import estrellaCompleta from '.././assets/estrella (1).png'
import { useEffect, useState } from 'react'
import useEmblaCarousel from 'embla-carousel-react'
import { useNavigate } from 'react-router-dom'

type Props = {
  producto: Producto
  isSelected: boolean
  anySelected: boolean
  onSelect: () => void
  onEdit: (produto: Producto) => void
  onDelete: (id: number) => void
}

const ProductCard = (props: Props) => {

    const navigate = useNavigate()
    const [favourite, setFavourite] = useState(false)
    const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true})

    const bestSeller = () => {
        props.producto.categorias.map((categoria) => (
            categoria.es_principal && setFavourite(true)
        ))
    }
    useEffect(() => {
        bestSeller()
    })

  return (
    <div
      onClick={e => {e.stopPropagation(); props.onSelect()}}
      className={`flex flex-col bg-blue-100 rounded-2xl shadow-md overflow-hidden cursor-pointer transition-all duration-300 ${props.isSelected ? 'ring-2 ring-orange-400 relative z-10 -translate-y-4 w-72 md:w-80 shadow-2xl' : props.anySelected ? 'w-36 md:w-48 opacity-40 blur-sm scale-95' : 'w-36 md:w-48 hover:shadow-xl hover:-translate-y-1'}`}
    >
        {favourite && <img src={estrellaCompleta} className='absolute w-6 ml-1 mt-1 z-10' />}
        {props.producto.disponible && (
          <span className='absolute top-1 right-1 z-10 bg-green-500 text-white text-xs font-bold px-2 py-0.5 rounded-full'>
            ✓ Disponible
          </span>
        )}
        <div className='relative'>
            <div className='overflow-hidden' ref={emblaRef}>
                <div className='flex'>
                    {props.producto.imagenes_url?.length > 0 ? (
                      props.producto.imagenes_url.map((imagen, index) => (
                        <div key={index} className='flex-none w-full'>
                            <img
                              src={imagen}
                              alt={props.producto.nombre}
                              className={`h-32 w-full object-cover ${props.isSelected && 'h-50'}`}
                              onError={e => { (e.target as HTMLImageElement).src = 'https://as1.ftcdn.net/jpg/10/22/24/80/220_F_1022248039_7LDxHRi3Mlt9BK3wzLBUGZp9XAO1gt2s.jpg' }}
                            />
                        </div>
                      ))
                    ) : (
                      <div className='flex-none w-full'>
                        <img
                          src='https://as1.ftcdn.net/jpg/10/22/24/80/220_F_1022248039_7LDxHRi3Mlt9BK3wzLBUGZp9XAO1gt2s.jpg'
                          alt={props.producto.nombre}
                          className='h-32 w-full object-cover'
                        />
                      </div>
                    )}
                </div>
            </div>
            {props.isSelected && (
              <button
                onClick={e => { e.stopPropagation(); emblaApi?.scrollPrev() }}
                className='absolute left-1 top-1/2 -translate-y-1/2 z-10 bg-black/40 text-white rounded-full w-6 h-6 flex items-center justify-center hover:bg-black/60'
              >
                ‹
              </button>
            )}
            {props.isSelected && (
              <button
                onClick={e => { e.stopPropagation(); emblaApi?.scrollNext() }}
                className='absolute right-1 top-1/2 -translate-y-1/2 z-10 bg-black/40 text-white rounded-full w-6 h-6 flex items-center justify-center hover:bg-black/60'
              >
                ›
              </button>
            )}
        </div>
      <div className='flex flex-1 flex-col gap-2 p-3 text-center h-fit'>
        <h3 className='font-paytone text-gray-800 text-lg leading-tight text-ellipsis'>{props.producto.nombre}</h3>
        <p className='text-gray-400 text-xs mt-auto'>{props.producto.descripcion}</p>
        <div className='flex justify-between mr-2 mt-2'>
            <p className='font-bebas text-gray-500'>Precio:</p>
            <p className='font-bebas text-gray-500'>${props.producto.precio_base}</p>
        </div>
        <div className='flex justify-between mr-2'>
            <p className='font-bebas text-gray-500'>Stock:</p>
            <p className='font-bebas text-gray-500'>{props.producto.stock_cantidad}</p>
        </div>
        {props.isSelected && (
          <button
            onClick={e => { e.stopPropagation(); navigate(`/productos/${props.producto.id}`) }}
            className='w-full text-white bg-orange-400 py-1 rounded-lg text-sm font-semibold hover:bg-orange-500 transition-colors mt-1'
          >
            Detalles
          </button>
        )}
        <div className='flex gap-2 mt-auto'>
          <button
            onClick={e => { e.stopPropagation(); props.onEdit(props.producto) }}
            className='flex-1 text-orange-500 border-2 border-orange-400 py-1 rounded-lg text-sm font-semibold hover:bg-orange-50 transition-colors'
          >
            Editar
          </button>
          <button
            onClick={e => {e.stopPropagation(); props.onDelete(props.producto.id)}}
            className='flex-1 text-red-500 border-2 border-red-400 py-1 rounded-lg text-sm font-semibold hover:bg-red-50 transition-colors'
          >
            Borrar
          </button>
        </div>
      </div>
    </div>
  )
}

export default ProductCard