import { useNavigate } from 'react-router-dom'
import type { Categoria } from '../types/Category'

type Props = {
  categoria: Categoria
  nombrePadre?: string | null
  isSelected: boolean
  anySelected: boolean
  onSelect: () => void
  onEdit: (categoria: Categoria) => void
  onDelete: (id: number) => void
}

const CategoryCard = (props: Props) => {
  const navigate = useNavigate()

  return (
    <div
      onClick={e => { e.stopPropagation(); props.onSelect() }}
      className={`flex flex-col ${props.nombrePadre ? 'bg-sky-100' : 'bg-indigo-100'} rounded-2xl shadow-md overflow-hidden cursor-pointer transition-all duration-300 ${props.isSelected ? 'ring-2 ring-orange-400 relative z-10 -translate-y-4 w-72 md:w-80 shadow-2xl' : props.anySelected ? 'w-36 md:w-48 opacity-40 blur-sm scale-95' : 'w-36 md:w-48 hover:shadow-xl hover:-translate-y-1'}`}
    >
      <img
        src={props.categoria.imagen_url !== 'string' ? props.categoria.imagen_url : 'https://as1.ftcdn.net/jpg/10/22/24/80/220_F_1022248039_7LDxHRi3Mlt9BK3wzLBUGZp9XAO1gt2s.jpg'}
        alt={props.categoria.nombre}
        className='h-32 w-full object-cover'
        onError={e => { (e.target as HTMLImageElement).src = 'https://as1.ftcdn.net/jpg/10/22/24/80/220_F_1022248039_7LDxHRi3Mlt9BK3wzLBUGZp9XAO1gt2s.jpg' }}
      />
      <div className='flex flex-1 flex-col gap-2 p-3 text-center h-fit'>
        <h3 className='font-paytone text-gray-800 text-lg leading-tight'>{props.categoria.nombre}</h3>
        <p className='text-gray-400 text-xs'>{props.categoria.descripcion}</p>

        {props.isSelected && (
          <button
            onClick={e => { e.stopPropagation(); navigate(`/categorias/${props.categoria.id}`) }}
            className='w-full text-white bg-orange-400 py-1 rounded-lg text-sm font-semibold hover:bg-orange-500 transition-colors mt-1'
          >
            Detalles
          </button>
        )}

        <div className='flex gap-2 mt-auto'>
          <button
            onClick={e => { e.stopPropagation(); props.onEdit(props.categoria) }}
            className='flex-1 text-orange-500 border-2 border-orange-400 py-1 rounded-lg text-sm font-semibold hover:bg-orange-50 transition-colors'
          >
            Editar
          </button>
          <button
            onClick={e => { e.stopPropagation(); props.onDelete(props.categoria.id) }}
            className='flex-1 text-red-500 border-2 border-red-400 py-1 rounded-lg text-sm font-semibold hover:bg-red-50 transition-colors'
          >
            Borrar
          </button>
        </div>
      </div>
    </div>
  )
}

export default CategoryCard
