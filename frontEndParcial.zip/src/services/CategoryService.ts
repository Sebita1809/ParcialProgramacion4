const BASE_URL = 'http://127.0.0.1:8000'                                                                                                                                                                                   
    export const getCategorias = async () => {                                                                                                                                                                                 
        const response = await fetch(`${BASE_URL}/categories/`)                                                                                                                                                                  
        if (!response.ok) throw new Error(`Error: ${response.status}`)                                                                                                                                                           
        return response.json()
    }

  export const createCategoria = async (body: object) => {
    const response = await fetch(`${BASE_URL}/categories/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    })
    if (!response.ok) throw new Error(`Error: ${response.status}`)
    return response.json()
  }

  export const updateCategoria = async (id: number, body: object) => {
    const response = await fetch(`${BASE_URL}/categories/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    })
    if (!response.ok) throw new Error(`Error: ${response.status}`)
    return response.json()
  }

  export const deleteCategoria = async (id: number) => {
    const response = await fetch(`${BASE_URL}/categories/${id}`, { method: 'DELETE' })
    if (!response.ok) throw new Error(`Error: ${response.status}`)
  }