const BASE_URL = 'http://127.0.0.1:8000'

export const getIngredientes = async () => {
  const response = await fetch(`${BASE_URL}/ingredients/`)
  if (!response.ok) throw new Error(`Error: ${response.status}`)
  return response.json()
}

export const createIngrediente = async (body: object) => {
  const response = await fetch(`${BASE_URL}/ingredients/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  })
  if (!response.ok) throw new Error(`Error: ${response.status}`)
  return response.json()
}

export const updateIngrediente = async (id: number, body: object) => {
  const response = await fetch(`${BASE_URL}/ingredients/${id}/`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  })
  if (!response.ok) throw new Error(`Error: ${response.status}`)
  return response.json()
}

export const deleteIngrediente = async (id: number) => {
  const response = await fetch(`${BASE_URL}/ingredients/${id}/`, { method: 'DELETE' })
  if (!response.ok) throw new Error(`Error: ${response.status}`)
}
