const BASE_URL = 'http://127.0.0.1:8000'

export const getProductos = async () => {
  const response = await fetch(`${BASE_URL}/products/`)
  if (!response.ok) throw new Error(`Error: ${response.status}`)
  return response.json()
}

export const createProducto = async (body: object) => {
  const response = await fetch(`${BASE_URL}/products/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  })
  if (!response.ok) throw new Error(`Error: ${response.status}`)
  return response.json()
}

export const updateProducto = async (id: number, body: object) => {
  const response = await fetch(`${BASE_URL}/products/${id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  })
  if (!response.ok) throw new Error(`Error: ${response.status}`)
  return response.json()
}

export const deleteProducto = async (id: number) => {
  const response = await fetch(`${BASE_URL}/products/${id}`, { method: 'DELETE' })
  if (!response.ok) throw new Error(`Error: ${response.status}`)
}
