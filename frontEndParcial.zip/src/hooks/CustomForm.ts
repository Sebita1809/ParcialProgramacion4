import { useState } from "react"


const useForm = <T>(initiaState: T) => {
    const [values, setValues] = useState<T>(initiaState)
    const handleChange = <K extends keyof T>(field: K, value: T[K]) => {
        setValues(prev => ({ ...prev, [field]: value}))
    }

    const reset = () => {
        setValues(initiaState)
    }
    return {
        values, 
        handleChange,
        reset
    }
}

export default useForm