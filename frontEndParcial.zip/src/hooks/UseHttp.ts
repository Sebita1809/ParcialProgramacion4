import { useState } from 'react'

export const useHttp = () => {

  const [state, setState] = useState({
    isLoading: false,
    hasError: null
  })

  const execute = async (url: string, method: string, body?: object) => {
    setState({ isLoading: true, hasError: null })

    try {
      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: body ? JSON.stringify(body) : undefined
      })

      if (!response.ok) {
        throw new Error(`Error: ${response.status} - ${response.statusText}`)
      }
    } catch (error) {
      setState({ isLoading: false, hasError: error.message })
    }

    setState({ isLoading: false, hasError: null })
  }

  return {
    execute,
    isLoading: state.isLoading,
    hasError: state.hasError
  }
}
