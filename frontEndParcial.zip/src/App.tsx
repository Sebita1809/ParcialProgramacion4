import { Routes, Route, Navigate } from 'react-router-dom'
import CategoriaPage from "./pages/CategoriaPage"
import IngredientePage from "./pages/IngredientPage"
import ProductPage from "./pages/ProductPage"
import CategoriaDetailPage from "./pages/CategoriaDetailPage"
import ProductoDetailPage from "./pages/ProductoDetailPage"

const App = () => {

  return (
    <Routes>
      <Route path='/' element={<Navigate to='/categorias' replace />}/>
      <Route path='/categorias' element={<CategoriaPage/>}/>
      <Route path='/categorias/:id' element={<CategoriaDetailPage/>}/>
      <Route path='/ingredientes' element={<IngredientePage/>}/>
      <Route path='/productos' element={<ProductPage/>}/>
      <Route path='/productos/:id' element={<ProductoDetailPage/>}/>
    </Routes>
  )

}

export default App