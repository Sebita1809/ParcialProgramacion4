export type Categoria = {
    id: number
    parent_id: number
    nombre: string
    descripcion: string
    imagen_url: string
    activo: string
    created_at: Date
    updated_at: Date
    deleted_at: Date
}
