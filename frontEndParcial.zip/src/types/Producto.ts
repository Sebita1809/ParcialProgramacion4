type CategoryList = {
    id: number
    nombre: string
    es_principal: boolean
}
type IngredienteList = {
    id: number
    nombre: string
    es_removible: boolean
}
export type Producto = {
    id: number
    nombre: string
    descripcion: string
    precio_base: number
    imagenes_url: [string]
    stock_cantidad: number
    categorias: [CategoryList]
    ingredientes: [IngredienteList]
    created_at: Date
    updated_at: Date
    deleted_at: Date
    disponible: boolean
    activo: boolean
}