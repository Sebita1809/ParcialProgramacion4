export type Ingrediente = {
    id: number
    nombre: string
    descripcion: string
    es_alergeno: boolean
    created_at: Date
    updated_at: Date
    activo: boolean
}